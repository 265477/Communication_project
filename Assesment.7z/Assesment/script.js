function redirect(url) {
    window.location.href = url;
}

function validate() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (email == "") {
      alert("Please enter email");
      return false;
    }

    if (password == "") {
      alert("Please enter password");
      return false;
    }
    // Fetch users from localStorage and set loggedInUser
    let users = localStorage.getItem("users")
      ? JSON.parse(localStorage.getItem("users"))
      : [];
    let userFound = users.some(
      (user) => user.email === email && user.password === password
    );

    if (userFound) {
      localStorage.setItem("loggedInUser", email);
      window.location.href = "LoginSuccess.html";
    } else {
      alert("User not found");
    }
    return false;
  }

  function validatefields() {
    let fullname = document.getElementById("fullname").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    debugger;
    if (fullname == "") {
      alert("Please enter fullname");
      return false;
    } else if (email == "") {
      alert("Please enter email");
      return false;
    } else if (password == "") {
      alert("Please enter password");
      return false;
    } else if (confirmPassword == "") {
      alert("Please enter confirm password");
      return false;
    }

    let user = {
      id: Number(new Date()),
      fullname: fullname,
      email: email,
      password: password,
    };

    let users = localStorage.getItem("users")
      ? JSON.parse(localStorage.getItem("users"))
      : [];
    users.push(user); // add item inside array
    localStorage.setItem("users", JSON.stringify(users));
    return true;
  }